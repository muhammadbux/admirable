import os

swagger_json_file = os.path.join(
    os.path.dirname(__file__),
    "swagger.json"
)
