python -m disco.cli --config config.yaml
